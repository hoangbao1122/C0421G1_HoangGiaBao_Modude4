package com.codegym.model.service;

import com.codegym.model.entity.User;

public interface IUserService {
    void save(User user);
}
